<?php

require_once "config/database.php";
require_once "repository/PeliculaRepository.php";
require_once "services/PeliculaService.php";
require_once "controllers/PeliculaController.php";

$db = (new Database())->connect();
$repo = new PeliculaRepository($db);
$service = new PeliculaService($repo);
$controller = new PeliculaController($service);

require_once "routes/api.php";