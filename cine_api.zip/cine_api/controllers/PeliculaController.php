<?php

class PeliculaController {

    private $service;

    public function __construct($service) {
        $this->service = $service;
    }

    public function crear() {
        $data = json_decode(file_get_contents("php://input"));
        echo json_encode($this->service->crear($data));
    }

    public function listar() {
        echo json_encode($this->service->listar());
    }

    public function actualizar($id) {
        $data = json_decode(file_get_contents("php://input"));
        echo json_encode($this->service->actualizar($id, $data));
    }

    public function eliminar($id) {
        echo json_encode($this->service->eliminar($id));
    }

    public function buscar() {
        echo json_encode($this->service->buscarPorNombre($_GET['nombre']));
    }

    public function peliculasPorFecha($fecha) {
        echo json_encode($this->service->peliculasPorFecha($fecha));
    }

    public function estadoSala($nombre) {
        echo json_encode($this->service->estadoSala($nombre));
    }
}