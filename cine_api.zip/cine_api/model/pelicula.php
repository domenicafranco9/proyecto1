<?php

class Pelicula {

    public $id_pelicula;
    public $nombre;
    public $duracion;
    public $activo;

    public function __construct($id, $nombre, $duracion, $activo = 1) {
        $this->id_pelicula = $id;
        $this->nombre = $nombre;
        $this->duracion = $duracion;
        $this->activo = $activo;
    }
}