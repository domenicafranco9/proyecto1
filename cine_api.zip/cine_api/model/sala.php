<?php

class Sala {

    public $id_sala;
    public $nombre;
    public $estado;
    public $activo;

    public function __construct($id, $nombre, $estado, $activo = 1) {
        $this->id_sala = $id;
        $this->nombre = $nombre;
        $this->estado = $estado;
        $this->activo = $activo;
    }
}