<?php

class PeliculaSala {

    public $id_pelicula_sala;
    public $id_sala_cine;
    public $id_pelicula;
    public $fecha_publicacion;
    public $fecha_fin;
    public $activo;

    public function __construct($id, $sala, $pelicula, $fecha_pub, $fecha_fin = null, $activo = 1) {
        $this->id_pelicula_sala = $id;
        $this->id_sala_cine = $sala;
        $this->id_pelicula = $pelicula;
        $this->fecha_publicacion = $fecha_pub;
        $this->fecha_fin = $fecha_fin;
        $this->activo = $activo;
    }
}