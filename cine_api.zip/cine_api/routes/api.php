<?php

$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', $_GET['url']);

if ($request[0] == "peliculas") {

    if ($method == "GET" && isset($_GET['nombre'])) {
        $controller->buscar();
    }

    elseif ($method == "GET") {
        $controller->listar();
    }

    elseif ($method == "POST") {
        $controller->crear();
    }

    elseif ($method == "PUT") {
        $controller->actualizar($request[1]);
    }

    elseif ($method == "DELETE") {
        $controller->eliminar($request[1]);
    }
}

if ($request[0] == "peliculas_fecha" && $method == "GET") {
    $controller->peliculasPorFecha($_GET['fecha']);
}

if ($request[0] == "estado_sala" && $method == "GET") {
    $controller->estadoSala($_GET['nombre']);
}