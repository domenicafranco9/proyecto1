<?php

class PeliculaRepository {

    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function crear($data) {

        $sql = "INSERT INTO pelicula (nombre, duracion)
                VALUES (:nombre, :duracion)";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':nombre', $data->nombre);
        $stmt->bindParam(':duracion', $data->duracion);

        return $stmt->execute();
    }

    public function listar() {

        $sql = "SELECT * FROM pelicula WHERE activo = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function actualizar($id, $data) {

        $sql = "UPDATE pelicula
                SET nombre = :nombre,
                    duracion = :duracion
                WHERE id_pelicula = :id";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':nombre', $data->nombre);
        $stmt->bindParam(':duracion', $data->duracion);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    public function eliminar($id) {

        $sql = "UPDATE pelicula
                SET activo = 0
                WHERE id_pelicula = :id";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    // Buscar por nombre
    public function buscarPorNombre($nombre) {

        $sql = "SELECT * FROM pelicula
                WHERE nombre LIKE :nombre
                AND activo = 1";

        $stmt = $this->conn->prepare($sql);
        $nombre = "%$nombre%";
        $stmt->bindParam(':nombre', $nombre);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    // Buscar por fecha de publicacion
    public function peliculasPorFecha($fecha) {

        $sql = "SELECT p.nombre, ps.fecha_publicacion
                FROM pelicula p
                JOIN pelicula_salacine ps
                ON p.id_pelicula = ps.id_pelicula
                WHERE ps.fecha_publicacion = :fecha
                AND p.activo = 1
                AND ps.activo = 1";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function contarPeliculasSala($nombreSala) {

        $sql = "CALL contar_peliculas_sala(:nombreSala)";
        $stmt = $this->conn->prepare($sql);

        $stmt->bindParam(':nombreSala', $nombreSala);
        $stmt->execute();

        $result = $stmt->fetch();
        return $result['total'];
    }
}