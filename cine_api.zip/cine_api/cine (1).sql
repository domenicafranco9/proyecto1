-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3307
-- Tiempo de generación: 03-03-2026 a las 21:50:22
-- Versión del servidor: 5.7.24
-- Versión de PHP: 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cine`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `contar_peliculas_sala` (IN `nombre_sala` VARCHAR(100))   BEGIN
    SELECT COUNT(*) AS total
    FROM pelicula_salacine ps
    JOIN sala_cine s ON ps.id_sala_cine = s.id_sala
    WHERE s.nombre = nombre_sala
      AND s.activo = TRUE
      AND ps.activo = TRUE;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pelicula`
--

CREATE TABLE `pelicula` (
  `id_pelicula` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `duracion` int(11) NOT NULL,
  `activo` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pelicula`
--

INSERT INTO `pelicula` (`id_pelicula`, `nombre`, `duracion`, `activo`) VALUES
(1, 'Titanic', 115, 1),
(2, 'Mario Bros', 112, 1),
(3, 'Interestelar', 169, 1),
(4, 'El Conjuro', 112, 1),
(5, 'Matrix', 136, 1),
(6, 'Avengers', 181, 1),
(7, 'Joker', 122, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pelicula_salacine`
--

CREATE TABLE `pelicula_salacine` (
  `id_pelicula_sala` int(11) NOT NULL,
  `id_sala_cine` int(11) NOT NULL,
  `id_pelicula` int(11) NOT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_fin` date DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `pelicula_salacine`
--

INSERT INTO `pelicula_salacine` (`id_pelicula_sala`, `id_sala_cine`, `id_pelicula`, `fecha_publicacion`, `fecha_fin`, `activo`) VALUES
(1, 1, 1, '2026-03-01', '2026-03-20', 1),
(2, 1, 2, '2026-03-02', '2026-03-22', 1),
(3, 2, 1, '2026-03-01', '2026-03-15', 1),
(4, 2, 2, '2026-03-02', '2026-03-16', 1),
(5, 2, 3, '2026-03-03', '2026-03-17', 1),
(6, 2, 4, '2026-03-04', '2026-03-18', 1),
(7, 3, 1, '2026-03-01', '2026-03-10', 1),
(8, 3, 2, '2026-03-02', '2026-03-11', 1),
(9, 3, 3, '2026-03-03', '2026-03-12', 1),
(10, 3, 4, '2026-03-04', '2026-03-13', 1),
(11, 3, 5, '2026-03-05', '2026-03-14', 1),
(12, 3, 6, '2026-03-06', '2026-03-15', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sala_cine`
--

CREATE TABLE `sala_cine` (
  `id_sala` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `activo` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `sala_cine`
--

INSERT INTO `sala_cine` (`id_sala`, `nombre`, `estado`, `activo`) VALUES
(1, 'Sala A', 'ACTIVA', 1),
(2, 'Sala B', 'ACTIVA', 1),
(3, 'Sala C', 'ACTIVA', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  ADD PRIMARY KEY (`id_pelicula`);

--
-- Indices de la tabla `pelicula_salacine`
--
ALTER TABLE `pelicula_salacine`
  ADD PRIMARY KEY (`id_pelicula_sala`),
  ADD KEY `id_sala_cine` (`id_sala_cine`),
  ADD KEY `id_pelicula` (`id_pelicula`);

--
-- Indices de la tabla `sala_cine`
--
ALTER TABLE `sala_cine`
  ADD PRIMARY KEY (`id_sala`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  MODIFY `id_pelicula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `pelicula_salacine`
--
ALTER TABLE `pelicula_salacine`
  MODIFY `id_pelicula_sala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `sala_cine`
--
ALTER TABLE `sala_cine`
  MODIFY `id_sala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pelicula_salacine`
--
ALTER TABLE `pelicula_salacine`
  ADD CONSTRAINT `pelicula_salacine_ibfk_1` FOREIGN KEY (`id_sala_cine`) REFERENCES `sala_cine` (`id_sala`),
  ADD CONSTRAINT `pelicula_salacine_ibfk_2` FOREIGN KEY (`id_pelicula`) REFERENCES `pelicula` (`id_pelicula`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
