<?php

class Database {

    private $host = "127.0.0.1";
    private $db_name = "cine";
    private $username = "root";
    private $password = "root";
    private $port = "3307"; 

    public function connect() {

        try {

            $conn = new PDO(
                "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset=utf8",
                $this->username,
                $this->password
            );

            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            return $conn;

        } catch (PDOException $e) {

            die("Error de conexión: " . $e->getMessage());
        }
    }
}