<?php

class PeliculaService {

    private $repository;

    public function __construct($repository) {
        $this->repository = $repository;
    }

    public function crear($data) {

        if(empty($data->nombre) || empty($data->duracion)) {
            return ["error" => "Datos incompletos"];
        }

        return $this->repository->crear($data);
    }

    public function listar() {
        return $this->repository->listar();
    }

    public function actualizar($id, $data) {
        return $this->repository->actualizar($id, $data);
    }

    public function eliminar($id) {
        return $this->repository->eliminar($id);
    }

    public function buscarPorNombre($nombre) {
        return $this->repository->buscarPorNombre($nombre);
    }

    public function peliculasPorFecha($fecha) {

        if (!DateTime::createFromFormat('Y-m-d', $fecha)) {
            return ["error" => "Formato inválido. Use YYYY-MM-DD"];
        }

        return $this->repository->peliculasPorFecha($fecha);
    }

    public function estadoSala($nombreSala) {

        $total = $this->repository->contarPeliculasSala($nombreSala);

        if ($total < 3) {
            return ["mensaje" => "Sala disponible"];
        } elseif ($total <= 5) {
            return ["mensaje" => "Sala con $total películas asignadas"];
        } else {
            return ["mensaje" => "Sala no disponible"];
        }
    }
}